# Dilatasi

A Pen created on CodePen.

Original URL: [https://codepen.io/editor/MBUH-aku/pen/01a0f223-d74b-7518-843b-e8d2246f164d](https://codepen.io/editor/MBUH-aku/pen/01a0f223-d74b-7518-843b-e8d2246f164d).

